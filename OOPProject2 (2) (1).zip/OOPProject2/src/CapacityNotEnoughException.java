/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tala
 */
public class CapacityNotEnoughException extends Exception{

    public CapacityNotEnoughException() {
        System.out.println("The capacity isn't enough");
    }
}
