
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tala
 */
public class Store implements CropKeeper{

    protected String name;
    protected int ID ;
    private int maxCapacityArea;
    private int usedCapacityArea;
    private int KGperSquareMeter = 10;
    protected ArrayList<Fruit> fruitList;


    public Store(String name, int ID, int maxCapacityArea, int usedCapacityArea) {
        this.name = name;
        this.maxCapacityArea = maxCapacityArea;
        this.usedCapacityArea = usedCapacityArea;
        fruitList = new ArrayList<Fruit>();
        this.ID = ID;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Fruit> getFruitList() {
        return fruitList;
    }

    public int getID() {
        return ID;
    }

    public int getMaxCapacityArea() {
        return maxCapacityArea;
    }

    public void setMaxCapacityArea(int maxCapacityArea) {
        this.maxCapacityArea = maxCapacityArea;
    }

    public int getUsedCapacityArea() {
        return usedCapacityArea;
    }

    public void setUsedCapacityArea(int usedCapacityArea) {
        this.usedCapacityArea = usedCapacityArea;
    }
    
    public int getKGperSquareMeter() {
        return KGperSquareMeter;
    }

    public void setKGperSquareMeter(int KGperSquareMeter) {
        this.KGperSquareMeter = KGperSquareMeter;
    }
    
    public int availabeCapacity(){
        return maxCapacityArea - usedCapacityArea;
    }
    
    public boolean canBeStored(Fruit f){
        for (int i = 0; i < fruitList.size(); i++) {
            if ((f.compareTo(fruitList.get(i))) != 0 ){
                if (availabeCapacity() > 0)
                    return true;
                else return false;
            }
        }    
        return true;
    }
    
    public void importCrop(Fruit f) throws CapacityNotEnoughException{
        if (canBeStored(f)){
            fruitList.add(f);
            usedCapacityArea += (f.weight/KGperSquareMeter);
        }
        else throw new CapacityNotEnoughException();
    }
    
    public void exportCrop(Fruit f) throws FruitNotFoundException{
        for (int i = 0; i < fruitList.size(); i++) {
            if (f.compareTo(fruitList.get(i)) == 0) {
                fruitList.remove(i);
                usedCapacityArea -= (f.weight/KGperSquareMeter);
            }
            else throw new FruitNotFoundException();
        }
    }

    @Override
    public String howToStore(Crop i) {
       // System.out.println("A Store stores fruits in large refrigerated cooler rooms\nAnd it keeps vegetables in sheds, not listed" );
        if (i instanceof Fruit)
            return "It's stored in large refrigerated cooler rooms";
        else return "It's kept in shed";
    }

}