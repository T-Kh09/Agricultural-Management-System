/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tala
 */
public class Fruit extends Crop implements Comparable<Fruit>{
    protected String taste;
    protected int price;
    protected String color;
    protected CropKeeper cropKeeper;

    public Fruit(String name, int weight, String cultivatedSeason, String taste, int price) {
        super(name, weight, cultivatedSeason);
        this.taste = taste;
        this.price = price;
    }


    @Override
    public String toString() {
        return "Fruit name: " + name + " Fruit weight: " + weight + " Cultivated season: " + cultivatedSeason + " taste: " + taste + " price: " + price;
    }

    public String consumeIt() {
        return "Fruits are consumed raw";
    }

    public void storeIt(Store store) throws CanNotBeStoredException{
        try {
            store.importCrop(this);
        } catch (CapacityNotEnoughException exception) {
            throw new CanNotBeStoredException();
        }
    }

    @Override
    public int compareTo(Fruit fruit) {
        if ((this.name.equals(fruit.name)) && (this.color.equals(fruit.color)))
            return 0;
        else return this.weight - fruit.weight;
    }
    
}
