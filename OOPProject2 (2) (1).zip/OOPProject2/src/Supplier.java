
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tala
 */
public class Supplier implements CropKeeper{
    private String name;
    private int ID;
    private int budget;
    protected ArrayList<Crop> cropList;

    public Supplier(String name, int ID, int budget) {
        this.name = name;
        this.budget = budget;
        this.ID=ID;
        cropList = new ArrayList<>();
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getBudget() {
        return budget;
    }

    public void setBudget(int budget) {
        this.budget = budget;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Crop> getCropList() {
        return cropList;
    }

    public void setCropList(ArrayList<Crop> cropList) {
        this.cropList = cropList;
    }
    
    
    
    public void buyCrop(Crop c, Store store) throws SupplierHasNotEnougMoneyException, FruitNotAvailableException{
        if (c instanceof Fruit ) {
            for (int i = 0; i < store.fruitList.size(); i++) {
                if(store.fruitList.get(i).name == ((Fruit) c).name){
                  if (budget >= ((Fruit) c).price) {
                      cropList.add(c);
                       budget -= ((Fruit) c).price * ((Fruit) c).weight;
                       store.fruitList.remove((Fruit) c);
                 }
                  else throw new SupplierHasNotEnougMoneyException();    
                }
                else throw new FruitNotAvailableException();
            }
        }
    }
    
    public  void sellCrop(Crop c, Store store) throws FruitNotFoundException, CanNotBeStoredException{
        if (c instanceof Fruit ){
            for (int i = 0; i < cropList.size(); i++) {
                if (cropList.get(i) == c) {
                    cropList.remove(c);
                    ((Fruit) c).storeIt(store);
                    budget += ((Fruit) c).price * ((Fruit) c).weight;
                }
                else throw new FruitNotFoundException();
            }
        }
    }

    @Override
    public String howToStore(Crop i) {
        if (i instanceof Fruit)
            return "It's stored in big refrigerators";
        //System.out.println("A Supplier keeps fruits in big refrigerators.\nAnd they keeps vegetables in the field booths.");
        else return "Vegetables are kept in the field booth";
    }

}

