/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tala
 */
public class FruitNotFoundException extends Exception{

    public FruitNotFoundException() {
        System.out.println("This fruit can't be found");
    }
    
}
