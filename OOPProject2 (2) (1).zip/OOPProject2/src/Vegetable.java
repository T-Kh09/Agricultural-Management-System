
public class Vegetable extends Crop implements Comparable<Vegetable>{
    protected String cultivatedRegion;
    protected CropKeeper cropKeeper;

    public Vegetable(String name, int weight, String cultivatedRegion, String cultivatedSeason) {
        super(name, weight, cultivatedSeason);
        this.cultivatedRegion = cultivatedRegion;
    }

    public Vegetable(String name, int weight, String cultivatedRegion) {
        super(name, weight, null);
        this.cultivatedRegion = cultivatedRegion;
    }

    @Override
    public String toString() {
        return "Vegetable name: " + name + " Vegetable weight: " + weight + " Cultivated season: " + cultivatedSeason + " Cultivated Region: " + cultivatedRegion;
    }

    public String consumeIt() {
        return "Vegetables are cooked";
    }

    public void storeIt(Store store) throws CanNotBeStoredException{
        throw new CanNotBeStoredException();
    }

    @Override
    public int compareTo(Vegetable vegetable) {
        if(this.name.equals(vegetable.name))
            return 0;
        else return this.weight - vegetable.weight;
    }
    
    
}
